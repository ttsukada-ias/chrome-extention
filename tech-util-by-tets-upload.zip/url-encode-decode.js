const input = document.getElementById("urlInput");
const output = document.getElementById("urlOutput");
const encodeButton = document.getElementById("encodeButton");
const decodeButton = document.getElementById("decodeButton");
const copyButton = document.getElementById("copyButton");
const status = document.getElementById("status");

function setStatus(message, isError = false) {
  status.textContent = message;
  status.classList.toggle("error", isError);
}

function getInputValue(action) {
  const value = String(input.value || "");
  if (!value) {
    throw new Error(`Enter text to ${action}.`);
  }
  return value;
}

function setOutput(value, message) {
  output.value = value;
  copyButton.disabled = !value;
  setStatus(message);
}

function encodeUrlText() {
  try {
    const value = getInputValue("encode");
    setOutput(encodeURIComponent(value), "Encoded URL-safe string.");
  } catch (error) {
    output.value = "";
    copyButton.disabled = true;
    setStatus(error && error.message ? error.message : String(error), true);
  }
}

function decodeUrlText() {
  try {
    const value = getInputValue("decode");
    setOutput(decodeURIComponent(value.replace(/\+/g, " ")), "Decoded URL-encoded string.");
  } catch (error) {
    output.value = "";
    copyButton.disabled = true;
    setStatus("Unable to decode input. Check for malformed percent-encoding.", true);
  }
}

async function copyOutput() {
  if (!output.value) return;

  try {
    await navigator.clipboard.writeText(output.value);
    setStatus("Output copied to clipboard.");
  } catch (error) {
    output.focus();
    output.select();
    document.execCommand("copy");
    setStatus("Output copied to clipboard.");
  }
}

encodeButton.addEventListener("click", encodeUrlText);
decodeButton.addEventListener("click", decodeUrlText);
copyButton.addEventListener("click", copyOutput);
